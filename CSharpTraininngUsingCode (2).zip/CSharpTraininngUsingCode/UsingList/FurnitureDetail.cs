using System;

namespace UsingList
{
    public class FurnitureDetail
    {
        public int Id;
        public string Name,Description,FurnitureType;
        public float Price;
        
    }
}