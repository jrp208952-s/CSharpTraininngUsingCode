using System;
using System.Collections.Generic;

namespace UsingList
{
    public class FurnitureList:FurnitureDetail
    {
        List<FurnitureDetail> Furniture=new List<FurnitureDetail>
        {
            new FurnitureDetail{Id=1,Name="Chair",Description="Office Chair",FurnitureType="Steel+Fiber",Price=1500},
            new FurnitureDetail{Id=2,Name="Table",Description="Dianing Table+Chair",FurnitureType="Wooden",Price=3500},
            new FurnitureDetail{Id=3,Name="Sofa",Description="Livingroom Sofa",FurnitureType="Steel",Price=15500},
            new FurnitureDetail{Id=4,Name="WordRob",Description="Office Chair",FurnitureType="Wooden",Price=7500},
            new FurnitureDetail{Id=5,Name="Kitchen Cabinet",Description="Kitchen Cabinet",FurnitureType="Wooden",Price=11500},
        };

        public void GetFurniture()
        {
            foreach(var Furniturelist in Furniture)
            {
                Console.WriteLine("\t"+Furniturelist.Id+"\t"+Furniturelist.Name+"\t"+Furniturelist.Description+"\t"+Furniturelist.FurnitureType+"\t"+Furniturelist.Price+"\n");
            }
        }
        public void GetFurnitureById()
        {
            Console.WriteLine("Enter Product Id Which You Want To Search:");
            int id=Convert.ToInt32(Console.ReadLine());
            var FbyId=Furniture.Find(list=>list.Id==id);
            Console.WriteLine("\t"+FbyId.Id+"\t"+FbyId.Name+"\t"+FbyId.Description+"\t"+FbyId.FurnitureType+"\t"+FbyId.Price+"\n");
        }
        public void AddFurniture()
        {
            Console.WriteLine("Enter Product Id:");
            int FId=Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Product Name:");
            string FName=Console.ReadLine();
            Console.WriteLine("Enter Product Description:");
            string FDescription=Console.ReadLine();
            Console.WriteLine("Enter Product Type:");
            string FType=Console.ReadLine();
            Console.WriteLine("Enter Product Price:");
            float FPrice=float.Parse(Console.ReadLine());

            Furniture.Add(new FurnitureDetail{Id=FId,Name=FName,Description=FDescription,FurnitureType=FType,Price=FPrice});
        }
        public void DeleteFurniture()
        {
            Console.WriteLine("Enter Product Id Which You Want To Delete:");
            int id=Convert.ToInt32(Console.ReadLine());
            var FbyId=Furniture.Find(list=>list.Id==id);
            Furniture.Remove(FbyId);
        }
        public void UpdateFurniture()
        {
            Console.WriteLine("Enter Product Id Which You Want To Search:");
            int id=Convert.ToInt32(Console.ReadLine());
            var FbyId=Furniture.Find(list=>list.Id==id);
            Console.WriteLine("\t"+FbyId.Id+"\t"+FbyId.Name+"\t"+FbyId.Description+"\t"+FbyId.FurnitureType+"\t"+FbyId.Price+"\n");

            Console.WriteLine("\t\t\t\t\tEnter Product Deatil For Update");

            Console.WriteLine("Enter Product Id:");
            int FId=Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Product Name:");
            string FName=Console.ReadLine();
            Console.WriteLine("Enter Product Description:");
            string FDescription=Console.ReadLine();
            Console.WriteLine("Enter Product Type:");
            string FType=Console.ReadLine();
            Console.WriteLine("Enter Product Price:");
            float FPrice=float.Parse(Console.ReadLine());

            if(FbyId.Id!=0 && FbyId.Name!="" && FbyId.Description!="" && FbyId.FurnitureType!="" && FbyId.Price!=0)
            {
                FbyId.Id=FId;
                FbyId.Name=FName;
                FbyId.Description=FDescription;
                FbyId.FurnitureType=FType;
                FbyId.Price=FPrice;
            }  
            else
            {
                Console.WriteLine("Some Values Are Null Please Debug The CODE");
            }
        }

    }
}