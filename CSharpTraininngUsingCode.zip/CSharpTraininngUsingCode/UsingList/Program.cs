﻿using System;

namespace UsingList
{
    class Program
    {
        static void Main(string[] args)
        {
            FurnitureList flist=new FurnitureList();
            int Choice;
            do
            {
                Console.WriteLine("\t\t Menu\t");
                Console.WriteLine("  1.\tGet All Elements of List");
                Console.WriteLine("  2.\tGet List Elements By Id");
                Console.WriteLine("  3.\tAdd New List Element");
                Console.WriteLine("  4.\tRemove Elements From List");
                Console.WriteLine("  5.\tUpdate Elements From List");

                Console.WriteLine("Enter Your Choice:");
                Choice=Convert.ToInt32(Console.ReadLine());

                switch(Choice)
                {
                    case 1:
                        flist.GetFurniture();
                        break;
                    case 2:
                        flist.GetFurnitureById();
                        break;
                    case 3:
                        flist.AddFurniture();
                        flist.GetFurniture();
                        break;
                    case 4:
                        flist.DeleteFurniture();
                        flist.GetFurniture();
                        break;
                    case 5:
                        flist.UpdateFurniture();
                        flist.GetFurniture();
                        break;
                    default:
                        Console.WriteLine("Enter Your Your Choice in between 1 to 5!");
                        break;
                }
            }while(Choice!=0);
            
        }
    }
}
