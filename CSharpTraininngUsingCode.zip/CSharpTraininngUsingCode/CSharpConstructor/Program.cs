﻿using System;

namespace CSharpConstructor
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("How Many Student Detail You May Enter:");
            int Num=Convert.ToInt32(Console.ReadLine());
            Student student=new Student(Num);
            for(int i=0;i<Num;i++)
            {
                student.CountResult();
            }
        }
    }
}
