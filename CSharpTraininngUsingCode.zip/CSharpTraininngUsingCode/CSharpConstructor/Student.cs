using System;

namespace CSharpConstructor
{
    public class Student
    {
        int[] RollNo;
        int Num;
        string[] Name;
        float[] Marks;
        float Total,Percentage;

        public Student(int No)
        {
            RollNo=new int[No];
            Name=new string[No];
            for(int i=0;i<No;i++)
            {
                Console.WriteLine("Enter Student Roll Number:");
                RollNo[i]=Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter Student Name:");
                Name[i]=Console.ReadLine();
                Console.WriteLine("How Much Subject Marks You May Enter:");
                Num=Convert.ToInt32(Console.ReadLine());
                Marks=new float[Num];
                for(int j=0;j<Marks.Length;j++)
                {
                    Console.WriteLine($"Enter Student Marks For Subject{i}:");
                    Marks[i]=float.Parse(Console.ReadLine());
                }
                foreach(var Mark in Marks)
                {
                    Total+=Mark;
                }
                Percentage=Total/Marks.Length;    
            }
        }
        public void CountResult()
        {
            if(Percentage>90)
            {
                Console.WriteLine("Congratulation You are Passed with Distinction");
            }
            else if(Percentage<90 && Percentage>=70)
            {
                Console.WriteLine("Congratulation You are Passed with First Class");
            }
            else if(Percentage<70 && Percentage>=60)
            {
                Console.WriteLine("Congratulation You are Passed with Second Class");
            }
            else if(Percentage<60 && Percentage>=50)
            {
                Console.WriteLine("Congratulation You are Passed with Pass Class");
            }
            else if(Percentage<35)
            {
                Console.WriteLine("Oops,Better Luck Next Time");
            }
        }
    }
}