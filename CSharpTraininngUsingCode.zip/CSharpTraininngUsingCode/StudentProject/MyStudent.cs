﻿using System;
using System.Collections.Generic;
using TestStudent;

namespace StudentProject
{
    public class MyStudent
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("Enter Student Name:");
            string StudentName=Console.ReadLine();
            MyStudentDetail student=new MyStudentDetail(StudentName);
            Student studenttest=new Student();

            studenttest.StudentTest();
            
        }
    }
}
