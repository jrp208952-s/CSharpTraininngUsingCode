using System;
using StudentProject;
using Xunit;

namespace TestStudent
{
    public class Student
    {
        MyStudentDetail studentdetail=new MyStudentDetail("");
        
        [Fact]
        public void StudentTest()
        {
            studentdetail.AddDetail();
        }
    }
}
