using System;
using System.Collections.Generic;

namespace StudentProject
{
    public class MyStudentDetail
    {
        string Name;
        List<string> StudentName;
        float[] Marks;
        float Total,Percentage;

        public MyStudentDetail(string Name)
        {
            StudentName=new List<string>();
            this.Name=Name;
        }

        public void AddDetail()
        {
            StudentName.Add(Name);
            Console.WriteLine("How Many Subject Marks You May Enter:");
            int Num=Convert.ToInt32(Console.ReadLine());
            Marks =new float[Num];
            for(int i=0;i<Marks.Length;i++)
            {
                if(Marks[i]<=100 && Marks[i]>=0)
                {
                    Console.WriteLine($"Enter Marks for Subject{i}:");
                    Marks[i]=Convert.ToInt32(Console.ReadLine());
                }
                else
                {
                    Console.WriteLine("Please Enter Valid Marks..");
                }
            }
        }
        public void CalculateResult()
        {
            foreach(var  students in StudentName)
            {
                Console.WriteLine(students);
            }
           
            foreach(var Mark in Marks)
            {
                Total+=Mark;
            }
            Percentage=Total/Marks.Length; 
            
            Console.WriteLine("Total Marks of Student is:"+Total);
            Console.WriteLine("Percentage of Student is:"+Percentage);
            
            if(Percentage>90)
            {
                Console.WriteLine("Congratulation You are Passed with Distinction");
            }
            else if(Percentage<90 && Percentage>=70)
            {
                Console.WriteLine("Congratulation You are Passed with First Class");
            }
            else if(Percentage<70 && Percentage>=60)
            {
                Console.WriteLine("Congratulation You are Passed with Second Class");
            }
            else if(Percentage<60 && Percentage>=50)
            {
                Console.WriteLine("Congratulation You are Passed with Pass Class");
            }
            else if(Percentage<35)
            {
                Console.WriteLine("Oops,Better Luck Next Time");
            }
        }
    }
}