﻿using System;

namespace CSharpTraininngUsingCode
{
    class Program
    {
        static void Main(string[] args)
        {
            if(args.Length>0)
            {
                Console.WriteLine($"Welcome, {args[0]} and {args[1]} in C# Console Application");
            }
            else
            {
                Console.WriteLine("Opps Something Went  Wrong Here..");
            }
        }
    }
}
