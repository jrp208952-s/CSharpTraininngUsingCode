using System;

namespace ArrayExample
{
    public class First
    {
        public void AscSort()
        {
            int[] MyArray;
            Console.WriteLine("Enter Size of Array:");
            int Num=Convert.ToInt32(Console.ReadLine());
            MyArray=new int[Num];

            for(int i=0;i<MyArray.Length;i++)
            {
                Console.WriteLine("Enter Array Elements:");
                MyArray[i]=Convert.ToInt32(Console.ReadLine());
            }
            Array.Sort(MyArray);
            Console.WriteLine("Sorted Array Elemets Are:"); 
            foreach(var Elements in MyArray)
            {
                Console.Write(Elements+",");
            }
        }
        public void DescSort()
        {
            int[] MyArray;
            Console.WriteLine("Enter Size of Array:");
            int Num=Convert.ToInt32(Console.ReadLine());
            MyArray=new int[Num];

            for(int i=0;i<MyArray.Length;i++)
            {
                Console.WriteLine("Enter Array Elements:");
                MyArray[i]=Convert.ToInt32(Console.ReadLine());
            }
            Array.Reverse(MyArray);
            Console.WriteLine("Sorted Array Elemets Are:"); 
            foreach(var Elements in MyArray)
            {
                Console.WriteLine(Elements+",");
            }
        }
    }
}