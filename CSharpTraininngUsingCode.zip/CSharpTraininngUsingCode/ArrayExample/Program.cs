﻿using System;

namespace ArrayExample
{
    class Program
    {
        static void Main(string[] args)
        {
            First first=new First();
            int Choice;
            do{
                Console.WriteLine("\t\t\t\t\t\t\t\t\t\tMenu");  
                Console.WriteLine("\t\t1.\tAscending");  
                Console.WriteLine("\t\t2.\tDescending");
                
                Console.Write("Enter Your Choice:");
                Choice=Convert.ToInt32(Console.ReadLine());

                if(Choice==1)
                {
                    first.AscSort();
                }
                else if(Choice==2)
                {
                    first.DescSort();
                }
                else
                {
                    Console.WriteLine("Enter Your Choice Between 1 or 2!");
                }
            }while(Choice!=0);
        }
    }
}
